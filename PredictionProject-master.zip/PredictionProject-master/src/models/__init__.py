"""
Module de modélisation pour la prévision de commandes.

Contient les modèles de baseline et les modèles avancés.
"""

